<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Review Management';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reviewId = (int)($_POST['review_id'] ?? 0);
    $status = $_POST['review_status'] ?? '';
    if ($reviewId > 0 && in_array($status, ['pending', 'approved', 'rejected'], true)) {
        $stmt = $pdo->prepare('UPDATE reviews SET status=? WHERE id=?');
        $stmt->execute([$status, $reviewId]);
        flash('success', 'Review status updated to ' . ucfirst($status) . '.');
    }
    header('Location: reviews.php');
    exit;
}
$reviews = $pdo->query("SELECT r.*, u.name AS user_name, u.email, p.name AS package_name FROM reviews r JOIN users u ON u.id=r.user_id JOIN tour_packages p ON p.id=r.package_id ORDER BY CASE r.status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END, r.created_at DESC")->fetchAll();
$success = flash('success');
include '../includes/admin-header.php';
?>
<div class="admin-page-header"><div><h1>Review Management</h1><p>Approve or reject traveler reviews before they are shown publicly.</p></div><div class="admin-page-meta">Post-trip engagement</div></div>
<?php if($success):?><div class="alert alert-success admin-alert"><?php echo e($success);?></div><?php endif;?><div class="admin-table-card"><div class="admin-table-card-head"><h2>Submitted Reviews</h2><span><?php echo count($reviews);?> total</span></div><div class="admin-table-scroll"><table><thead><tr><th>Traveler</th><th>Package</th><th>Rating</th><th>Review</th><th>Submitted</th><th>Status</th></tr></thead><tbody><?php if(!$reviews):?><tr><td colspan="6" class="admin-empty-cell">No reviews submitted yet.</td></tr><?php endif;?><?php foreach($reviews as $r):?><tr><td><?php echo e($r['user_name']);?><br><small><?php echo e($r['email']);?></small></td><td><?php echo e($r['package_name']);?><br><small>Review #<?php echo (int)$r['id'];?></small></td><td><strong><?php echo str_repeat('★',(int)$r['rating']);?></strong><br><small><?php echo (int)$r['rating'];?>/5</small></td><td style="min-width:240px"><?php echo nl2br(e($r['comment']));?></td><td><?php echo $r['created_at']?date('d M Y',strtotime($r['created_at'])):'-';?></td><td><form method="POST" class="booking-status-select-form"><input type="hidden" name="review_id" value="<?php echo (int)$r['id'];?>"><select name="review_status" class="booking-status-select status-<?php echo e($r['status']);?>" onchange="this.form.submit()"><option value="pending" <?php echo $r['status']==='pending'?'selected':'';?>>Pending</option><option value="approved" <?php echo $r['status']==='approved'?'selected':'';?>>Approved</option><option value="rejected" <?php echo $r['status']==='rejected'?'selected':'';?>>Rejected</option></select></form></td></tr><?php endforeach;?></tbody></table></div></div><?php include '../includes/admin-footer.php'; ?>
