<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Admin Dashboard';

$stats = [
    'users' => (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'trip_types' => (int)$pdo->query("SELECT COUNT(*) FROM trip_categories WHERE status='active'")->fetchColumn(),
    'packages' => (int)$pdo->query("SELECT COUNT(*) FROM tour_packages WHERE status='active'")->fetchColumn(),
    'bookings' => (int)$pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn(),
    'reviews' => (int)$pdo->query("SELECT COUNT(*) FROM reviews WHERE status='pending'")->fetchColumn(),
];

$recent = $pdo->query("SELECT b.id, b.amount, b.booking_status, b.booking_date,
    u.name AS user_name, p.name AS package_name
    FROM bookings b
    JOIN users u ON u.id=b.user_id
    JOIN trips t ON t.id=b.trip_id
    JOIN tour_packages p ON p.id=t.package_id
    ORDER BY b.booking_date DESC LIMIT 6")->fetchAll();

include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div>
        <span class="admin-section-kicker">BUILD MY TOUR</span>
        <h1>Admin Dashboard</h1>
        <p>Manage users, trip types, tour packages, bookings and reviews from one place.</p>
    </div>
    <div class="admin-page-meta"><?php echo date('d M Y'); ?></div>
</div>

<div class="mini-admin-stats">
    <a href="users.php" class="mini-stat-card"><div><strong><?php echo $stats['users']; ?></strong><small>Users</small></div></a>
    <a href="trip-types.php" class="mini-stat-card"><div><strong><?php echo $stats['trip_types']; ?></strong><small>Trip Types</small></div></a>
    <a href="tour-packages.php" class="mini-stat-card"><div><strong><?php echo $stats['packages']; ?></strong><small>Active Packages</small></div></a>
    <a href="bookings.php" class="mini-stat-card"><div><strong><?php echo $stats['bookings']; ?></strong><small>Bookings</small></div></a>
    <a href="reviews.php" class="mini-stat-card <?php echo $stats['reviews'] ? 'has-alert' : ''; ?>"><div><strong><?php echo $stats['reviews']; ?></strong><small>Pending Reviews</small></div></a>
</div>

<section class="admin-panel-card mb-4">
    <div class="admin-section-head">
        <div><span class="admin-section-kicker">MANAGEMENT</span><h2>Manage BuildMyTour</h2></div>
    </div>
    <div class="mini-admin-actions">
        <a href="trip-types.php" class="mini-admin-action"><div><strong>Trip Types</strong><small>Manage planner categories</small></div><b>→</b></a>
        <a href="tour-packages.php" class="mini-admin-action"><div><strong>Tour Packages</strong><small>Package details, images, prices and offers</small></div><b>→</b></a>
        <a href="bookings.php" class="mini-admin-action"><div><strong>Bookings</strong><small>Review and update bookings</small></div><b>→</b></a>
        <a href="reviews.php" class="mini-admin-action"><div><strong>Reviews</strong><small>Approve customer reviews</small></div><b><?php echo $stats['reviews'] ?: '→'; ?></b></a>
    </div>
</section>

<section class="admin-table-card">
    <div class="admin-table-card-head"><div><span class="admin-section-kicker">RECENT ACTIVITY</span><h2>Recent Bookings</h2></div><a class="admin-table-view-all" href="bookings.php">View all →</a></div>
    <div class="admin-table-scroll">
        <table>
            <thead><tr><th>ID</th><th>Traveler</th><th>Package</th><th>Amount</th><th>Status</th></tr></thead>
            <tbody>
            <?php if (!$recent): ?>
                <tr><td colspan="5" class="admin-empty-row">No bookings yet.</td></tr>
            <?php else: foreach ($recent as $row): $status = strtolower((string)$row['booking_status']); ?>
                <tr>
                    <td><strong>#<?php echo (int)$row['id']; ?></strong></td>
                    <td><?php echo e($row['user_name']); ?></td>
                    <td><?php echo e($row['package_name']); ?></td>
                    <td><strong><?php echo formatMoney($row['amount']); ?></strong></td>
                    <td><span class="admin-status-badge admin-status-<?php echo e($status); ?>"><i></i><?php echo e(ucfirst($status)); ?></span></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php include '../includes/admin-footer.php'; ?>
