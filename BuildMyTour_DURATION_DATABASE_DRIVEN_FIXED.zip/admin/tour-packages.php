<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Tour Packages';

$categories = $pdo->query("SELECT id,name FROM trip_categories WHERE status='active' ORDER BY id")->fetchAll();
$edit = null;

if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM tour_packages WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}

function packageSlug(string $name): string {
    $slug = strtolower(trim($name));
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    return trim($slug, '-') ?: 'tour-package';
}

function uploadPackageImage(string $field, string $folder, string $fileName, bool $required = false): ?string {
    if (empty($_FILES[$field]['name'])) {
        if ($required) throw new RuntimeException('Please select all four travel images: Destination, Transport, Hotel and Meal Plan.');
        return null;
    }

    if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('One of the selected images could not be uploaded.');
    }

    if ($_FILES[$field]['size'] > 3 * 1024 * 1024) {
        throw new RuntimeException('Each image must be 3 MB or smaller.');
    }

    $tmp = $_FILES[$field]['tmp_name'];
    $mime = function_exists('mime_content_type') ? mime_content_type($tmp) : '';
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/avif' => 'avif',
    ];

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Only JPG, PNG, WEBP or AVIF images are allowed.');
    }

    if (!is_dir($folder) && !mkdir($folder, 0755, true)) {
        throw new RuntimeException('Travel image folder could not be created.');
    }

    $extension = $allowed[$mime];
    $target = rtrim($folder, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $fileName . '.' . $extension;

    foreach (['jpg','png','webp','avif'] as $oldExt) {
        $old = rtrim($folder, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $fileName . '.' . $oldExt;
        if ($old !== $target && is_file($old)) @unlink($old);
    }

    if (!move_uploaded_file($tmp, $target)) {
        throw new RuntimeException('The image could not be saved.');
    }

    return 'assets/images/packages/' . basename($folder) . '/' . $fileName . '.' . $extension;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $categoryId = (int)($_POST['category_id'] ?? 0);
        $days = max(1, (int)($_POST['days'] ?? 1));
        $price = max(0, (float)($_POST['price'] ?? 0));
        $route = trim($_POST['route'] ?? '');
        $description = trim($_POST['description'] ?? '');
                $status = in_array($_POST['status'] ?? 'active', ['active', 'inactive'], true) ? $_POST['status'] : 'active';

        if ($name === '' || $categoryId <= 0 || $price <= 0) {
            flash('error', 'Please complete the required package fields.');
            header('Location: tour-packages.php' . ($id ? '?edit=' . $id : ''));
            exit;
        }

        $old = null;
        if ($id) {
            $stmt = $pdo->prepare('SELECT * FROM tour_packages WHERE id=?');
            $stmt->execute([$id]);
            $old = $stmt->fetch();
            if (!$old) {
                flash('error', 'Tour package was not found.');
                header('Location: tour-packages.php');
                exit;
            }
        }

        $folderName = $old && !empty($old['image_destination']) ? basename(dirname($old['image_destination'])) : packageSlug($name);
        $folder = __DIR__ . '/../assets/images/packages/' . $folderName;
        $required = !$id;

        try {
            $images = [];
            foreach ([
                'image_destination' => 'destination',
                'image_transport' => 'transport',
                'image_hotel' => 'hotel',
                'image_meal_plan' => 'meal-plan',
            ] as $field => $fileName) {
                $images[$field] = uploadPackageImage($field, $folder, $fileName, $required);
            }

            if ($id) {
                $values = [
                    'category_id' => $categoryId,
                    'name' => $name,
                    'description' => $description,
                    'duration' => $days . ' Days / ' . max(0, $days - 1) . ' Nights',
                    'days' => $days,
                    'route' => $route,
                    'price' => $price,
                    'status' => $status,
                ];
                foreach ($images as $column => $path) {
                    if ($path !== null) $values[$column] = $path;
                }
                $set = [];
                $params = [];
                foreach ($values as $column => $value) {
                    $set[] = $column . '=?';
                    $params[] = $value;
                }
                $params[] = $id;
                $stmt = $pdo->prepare('UPDATE tour_packages SET ' . implode(',', $set) . ' WHERE id=?');
                $stmt->execute($params);
                flash('success', 'Tour package updated successfully.');
            } else {
                $stmt = $pdo->prepare('INSERT INTO tour_packages(category_id,name,description,duration,days,route,price,image_destination,image_transport,image_hotel,image_meal_plan,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');
                $stmt->execute([
                    $categoryId, $name, $description, $days . ' Days / ' . max(0, $days - 1) . ' Nights', $days, $route, $price,
                    $images['image_destination'], $images['image_transport'], $images['image_hotel'], $images['image_meal_plan'], $status
                ]);
                flash('success', 'Tour package added successfully.');
            }
        } catch (Throwable $e) {
            if (!$id && is_dir($folder)) {
                foreach (glob($folder . '/*') ?: [] as $item) { if (is_file($item)) @unlink($item); }
                @rmdir($folder);
            }
            $message = $e instanceof PDOException && (int)$e->errorInfo[1] === 1062
                ? 'A tour package with this name already exists.'
                : $e->getMessage();
            flash('error', $message ?: 'Tour package could not be saved.');
        }
        header('Location: tour-packages.php' . ($id ? '?edit=' . $id : ''));
        exit;
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare('SELECT image_destination FROM tour_packages WHERE id=?');
            $stmt->execute([$id]);
            $package = $stmt->fetch();
            $pdo->prepare('DELETE FROM tour_packages WHERE id=?')->execute([$id]);
            if ($package && !empty($package['image_destination'])) {
                $folder = __DIR__ . '/../assets/images/packages/' . basename(dirname($package['image_destination']));
                if (is_dir($folder)) {
                    foreach (glob($folder . '/*') ?: [] as $item) if (is_file($item)) @unlink($item);
                    @rmdir($folder);
                }
            }
            flash('success', 'Tour package deleted successfully.');
        } catch (Throwable $e) {
            flash('error', 'Package cannot be deleted because it is linked to an existing trip.');
        }
        header('Location: tour-packages.php');
        exit;
    }
}

$success = flash('success');
$error = flash('error');
$packages = $pdo->query('SELECT p.*, c.name AS category FROM tour_packages p JOIN trip_categories c ON c.id=p.category_id ORDER BY p.id ASC')->fetchAll();

function packageGalleryPaths(array $package): array {
    $items = [
        ['path' => $package['image_destination'] ?? '', 'label' => 'Destination'],
        ['path' => $package['image_transport'] ?? '', 'label' => 'Transport'],
        ['path' => $package['image_hotel'] ?? '', 'label' => 'Hotel'],
        ['path' => $package['image_meal_plan'] ?? '', 'label' => 'Meal Plan'],
    ];
    $result = [];
    foreach ($items as $item) {
        if ($item['path'] && is_file(__DIR__ . '/../' . $item['path'])) $result[] = $item;
    }
    return $result;
}

include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div>
        <span class="admin-section-kicker">SMART PLANNER CONTENT</span>
        <h1>Tour Packages</h1>
        <p>Manage each tour package and its four travel images from one simple form.</p>
    </div>
    <a href="tour-packages.php#package-form" class="btn btn-primary">+ Add Tour Package</a>
</div>

<?php if ($success): ?><div class="alert alert-success admin-alert"><?php echo e($success); ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger admin-alert"><?php echo e($error); ?></div><?php endif; ?>

<section class="admin-panel-card mb-4" id="package-form">
    <div class="admin-section-head">
        <div>
            <span class="admin-section-kicker"><?php echo $edit ? 'EDIT PACKAGE' : 'ADD PACKAGE'; ?></span>
            <h2><?php echo $edit ? 'Update Tour Package' : 'Add Tour Package'; ?></h2>
        </div>
        <?php if ($edit): ?><a href="tour-packages.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
    </div>

    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?php echo (int)($edit['id'] ?? 0); ?>">
        <div class="row g-3">
            <div class="col-md-7"><label class="form-label">Package Name</label><input class="form-control" name="name" required value="<?php echo e($edit['name'] ?? ''); ?>"></div>
            <div class="col-md-5"><label class="form-label">Trip Type</label><select class="form-select" name="category_id" required><option value="">Select Trip Type</option><?php foreach ($categories as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo ((int)($edit['category_id'] ?? 0) === (int)$c['id']) ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option><?php endforeach; ?></select></div>
            <div class="col-md-3"><label class="form-label">Days</label><input type="number" min="1" class="form-control" name="days" value="<?php echo e($edit['days'] ?? 4); ?>" required></div>
            <div class="col-md-3"><label class="form-label">Base Price / Person (₹)</label><input type="number" min="1" class="form-control" name="price" value="<?php echo e($edit['price'] ?? ''); ?>" required></div>
            <div class="col-md-3"><label class="form-label">Status</label><select class="form-select" name="status"><option value="active" <?php echo (($edit['status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option><option value="inactive" <?php echo (($edit['status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option></select></div>
            <div class="col-12"><label class="form-label">Route</label><input class="form-control" name="route" placeholder="City → City → City" value="<?php echo e($edit['route'] ?? ''); ?>"></div>
            <div class="col-12"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="2"><?php echo e($edit['description'] ?? ''); ?></textarea></div>
        </div>

        <div class="package-image-upload-box mt-4">
            <div class="travel-image-upload-head">
                <div><h3>Travel Images</h3><p>Upload four images for the selected tour package. JPG, PNG, WEBP or AVIF, max 3 MB each.</p></div>
                <?php if ($edit): ?><span class="text-muted small">Leave an image empty to keep the current image.</span><?php endif; ?>
            </div>
            <div class="row g-3">
                <?php
                $imageFields = [
                    ['image_destination','Destination Image','image_destination'],
                    ['image_transport','Transport Image','image_transport'],
                    ['image_hotel','Hotel Image','image_hotel'],
                    ['image_meal_plan','Meal Plan Image','image_meal_plan'],
                ];
                foreach ($imageFields as [$field,$label,$column]):
                    $current = $edit[$column] ?? '';
                ?>
                    <div class="col-md-6 col-lg-4 col-xl">
                        <div class="travel-upload-card">
                            <?php if ($current && is_file(__DIR__ . '/../' . $current)): ?><img src="../<?php echo e($current); ?>" alt="<?php echo e($label); ?>"><span class="travel-upload-current">Current</span><?php else: ?><div class="travel-upload-placeholder">No image</div><?php endif; ?>
                            <label class="form-label"><?php echo e($label); ?></label>
                            <input type="file" class="form-control form-control-sm" name="<?php echo e($field); ?>" accept="image/jpeg,image/png,image/webp,image/avif" <?php echo $edit ? '' : 'required'; ?>>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="mt-4 d-flex gap-2">
            <button class="btn btn-primary" type="submit"><?php echo $edit ? 'Update Package' : 'Add Tour Package'; ?></button>
            <?php if ($edit): ?><a href="tour-packages.php" class="btn btn-outline-secondary">Cancel</a><?php endif; ?>
        </div>
    </form>
</section>

<section class="admin-table-card">
    <div class="admin-table-card-head"><h2>All Tour Packages</h2><span><?php echo count($packages); ?> packages</span></div>
    <div class="admin-table-scroll">
        <table class="tour-package-table">
            <thead><tr><th>Images</th><th>Package</th><th>Trip Type</th><th>Days</th><th>Price / Person</th><th>Status</th><th class="actions-column">Action</th></tr></thead>
            <tbody>
            <?php foreach ($packages as $p): $gallery = packageGalleryPaths($p); ?>
                <tr>
                    <td class="package-images-cell">
                        <div class="admin-package-gallery">
                            <?php foreach ($gallery as $g): ?><div class="admin-package-gallery-item"><img src="../<?php echo e($g['path']); ?>" alt="<?php echo e($p['name'].' - '.$g['label']); ?>" loading="lazy"><span><?php echo e($g['label']); ?></span></div><?php endforeach; ?>
                        </div>
                        <small class="d-block mt-1"><?php echo count($gallery); ?>/4 images</small>
                    </td>
                    <td><strong><?php echo e($p['name']); ?></strong><br><small><?php echo e($p['route']); ?></small></td>
                    <td><?php echo e($p['category']); ?></td>
                    <td><?php echo (int)$p['days']; ?></td>
                    <td><strong><?php echo formatMoney($p['price']); ?></strong></td>
                    <td><span class="admin-status-badge admin-status-<?php echo e($p['status']); ?>"><i></i><?php echo ucfirst(e($p['status'])); ?></span></td>
                    <td class="actions-cell">
                        <div class="package-actions">
                            <a class="btn btn-sm btn-outline-primary" href="tour-packages.php?edit=<?php echo (int)$p['id']; ?>#package-form">Edit</a>
                            <form method="POST" onsubmit="return confirm('Delete this package and its four images?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>"><button class="btn btn-sm btn-outline-danger" type="submit">Delete</button></form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?php include '../includes/admin-footer.php'; ?>
