<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Users';

$users = $pdo->query("SELECT id, name, email, phone, created_at FROM users ORDER BY created_at DESC")->fetchAll();
include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div><h1>Users</h1><p>Manage all registered accounts.</p></div>
    <div class="admin-page-meta">Admin Panel</div>
</div>

<div class="admin-table-card">
    <div class="admin-table-card-head"><h2>Registered users</h2><span>Latest data</span></div>
    <div class="admin-table-scroll">
    <table>
    <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th></tr>
    <?php foreach ($users as $u): ?>
    <tr>
        <td><?php echo $u['id']; ?></td>
        <td><?php echo e($u['name']); ?></td>
        <td><?php echo e($u['email']); ?></td>
        <td><?php echo e($u['phone']); ?></td>
        
        <td><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
    </tr>
    <?php endforeach; ?>
</table>
    </div>
</div>

<?php include '../includes/admin-footer.php'; ?>
