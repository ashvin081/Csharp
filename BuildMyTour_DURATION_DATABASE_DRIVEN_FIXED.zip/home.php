<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Home';
include 'includes/header.php';
?>

<section class="hero">
    <div class="container">
        <h1>BuildMyTour</h1>
        <p class="tagline">Smart Travel Planning &amp; Booking System</p>
        <p class="desc">Plan smarter, explore destinations and manage your travel bookings in one place.</p>
        <div class="hero-actions">
            <a href="smart-trip-planner.php" class="btn btn-primary">Plan My Trip</a>
            <a href="my-bookings.php" class="btn btn-secondary">View My Bookings</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
