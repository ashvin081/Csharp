<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__.'/config/database.php';
requireLogin();
$pageTitle='Your Smart Tour Plan';
$tripId=(int)($_GET['trip_id']??0);
$s=$pdo->prepare('SELECT * FROM trips WHERE id=? AND user_id=?');
$s->execute([$tripId,currentUserId()]);
$trip=$s->fetch();
if(!$trip){header('Location: smart-trip-planner.php');exit;}
$package=getTourPackage($pdo,(int)$trip['package_id']);
if(!$package){header('Location: smart-trip-planner.php');exit;}
$storedPlan=!empty($trip['generated_plan_json'])?json_decode($trip['generated_plan_json'],true):[];
$storedPlan=is_array($storedPlan)?$storedPlan:[];
$sel=$_SESSION['selection'][$tripId]??$storedPlan;
$travelers=(int)$trip['travelers'];
$budget=(float)$trip['budget'];
$pricePerPerson=(float)$package['price'];
$total=round($pricePerPerson*$travelers,2);
$remaining=round($budget-$total,2);
$withinBudget=$remaining>=0;
$plan=$sel['activities']??[];
$transport=$sel['transport']??[];
$hotel=$sel['hotel']??[];
$meal=$sel['meal_plan']??'Breakfast + Lunch + Dinner';
$rooms=(int)($sel['hotel_rooms']??ceil($travelers/2));

// Each package keeps four supporting images in its own folder.
$packageFolder = dirname($package['image_destination']);
$gallery = [];
$galleryFiles = [
    ['file'=>'destination.jpg','label'=>'Destination','alt'=>$trip['destination'].' destination'],
    ['file'=>'transport.jpg','label'=>'Transport','alt'=>'Transport for '.$package['name']],
    ['file'=>'hotel.jpg','label'=>'Hotel','alt'=>'Hotel for '.$package['name']],
    ['file'=>'meal-plan.jpg','label'=>'Meal Plan','alt'=>'Meal plan for '.$package['name']],
];
foreach($galleryFiles as $item){
    $image=$packageFolder.'/'.$item['file'];
    if(file_exists(__DIR__.'/'.$image)) $gallery[]=['image'=>$image,'label'=>$item['label'],'alt'=>$item['alt']];
}
if(!$gallery) $gallery=[['image'=>'assets/images/placeholder.jpg','label'=>'Destination','alt'=>'Travel destination']];
$allPackages=getTourPackages($pdo,true);
$matchingPackages=[];
foreach($allPackages as $candidate){
    if($candidate['category']===$package['category'] && (int)$candidate['days']===(int)$trip['days']){
        $candidatePrice=(float)$candidate['price'];
        $candidateTotal=round($candidatePrice*$travelers,2);
        $matchingPackages[]=['package'=>$candidate,'total'=>$candidateTotal,'within'=>$candidateTotal<=$budget];
    }
}
usort($matchingPackages,fn($a,$b)=>$a['total']<=>$b['total']);
$hasAffordablePackage=(bool)array_filter($matchingPackages,fn($item)=>$item['within']);
include 'includes/header.php';
?>
<div class="container smart-planner-page py-4 py-md-5">
  <div class="planner-progress planner-progress-compact">
    <div class="progress-step done"><span>1</span><b>Trip Details</b></div><i>→</i>
    <div class="progress-step active"><span>2</span><b>Smart Tour Plan</b></div>
  </div>

  <?php if(count($matchingPackages)>1): ?>
  <section class="package-choice-card card border-0 shadow-sm mb-4">
    <div class="p-4">
      <div class="smart-trip-details-heading mb-3"><div><span>AVAILABLE PACKAGES</span><h2>Choose your tour package</h2></div></div>
      <div class="row g-3">
      <?php foreach($matchingPackages as $item): $cp=$item['package']; $isCurrent=(int)$cp['id']===(int)$package['id']; ?>
        <div class="col-md-6">
          <div class="package-choice-item<?php echo $isCurrent?' selected':''; ?><?php echo !$item['within']?' over-budget':''; ?>">
            <div><strong><?php echo e($cp['name']); ?></strong><small><?php echo e($cp['route']); ?></small></div>
            <div class="package-choice-price"><span><?php echo formatMoney($item['total']); ?> total</span><?php if($item['within']): ?><small>Within budget</small><?php else: ?><small>Over budget</small><?php endif; ?></div>
            <?php if(!$isCurrent): ?><form method="POST" action="select-package.php"><input type="hidden" name="trip_id" value="<?php echo $tripId; ?>"><input type="hidden" name="package_id" value="<?php echo (int)$cp['id']; ?>"><button class="btn btn-sm btn-outline-primary" type="submit"<?php echo !$item['within']?' disabled':''; ?>>Select</button></form><?php else: ?><span class="badge bg-primary-subtle text-primary">Selected</span><?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
      </div>
      <?php if(!$hasAffordablePackage): ?><div class="alert alert-warning mt-3 mb-0">All matching packages are above your selected budget. Increase your budget to continue.</div><?php endif; ?>
    </div>
  </section>
  <?php endif; ?>

  <section class="smart-planner-card card border-0 shadow-sm mb-4">
    <div class="smart-gallery-layout">
      <div class="smart-gallery">
        <div class="smart-gallery-main">
          <?php foreach($gallery as $i=>$item): ?>
            <img class="smart-gallery-main-image<?php echo $i===0?' active':''; ?>" src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['alt']); ?>" data-gallery-image="<?php echo $i; ?>">
          <?php endforeach; ?>
          <div class="smart-gallery-caption"><span id="galleryLabel"><?php echo e($gallery[0]['label']); ?></span><strong><?php echo count($gallery); ?></strong></div>
        </div>
        <div class="smart-gallery-thumbs" role="tablist" aria-label="Tour images">
          <?php foreach($gallery as $i=>$item): ?>
            <button type="button" class="smart-gallery-thumb<?php echo $i===0?' active':''; ?>" data-gallery-thumb="<?php echo $i; ?>" aria-label="<?php echo e($item['label']); ?> image">
              <img src="<?php echo e($item['image']); ?>" alt="">
              <span><?php echo e($item['label']); ?></span>
            </button>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="smart-gallery-summary">
        <span class="smart-planner-eyebrow">YOUR SMART TOUR PLAN</span>
        <h1><?php echo e($package['name']); ?></h1>
        <p><?php echo e($package['description']); ?></p>
        <div class="smart-plan-meta"><?php echo e(implode(' → ',$package['cities'])); ?></div>
        <div class="smart-gallery-facts">
          <div><span>TRAVEL DATES</span><strong><?php echo e(date('d M Y',strtotime($trip['start_date']))); ?> – <?php echo e(date('d M Y',strtotime($trip['end_date']))); ?></strong><small><?php echo (int)$trip['days']; ?> Days / <?php echo max(0,(int)$trip['days']-1); ?> Nights</small></div>
          <div><span>TRAVELERS</span><strong><?php echo $travelers; ?> Traveler<?php echo $travelers===1?'':'s'; ?></strong><small><?php echo e($package['category']); ?></small></div>
        </div>
      </div>

      <aside class="smart-plan-side smart-gallery-price">
        <div class="text-muted small">PRICE &amp; BUDGET</div>
        <div class="cost-line"><span>Price / person</span><strong><?php echo formatMoney($package['price']); ?></strong></div>
        <div class="cost-line"><span><?php echo $travelers; ?> travelers</span><strong><?php echo formatMoney($total); ?></strong></div>
        <div class="cost-line"><span>Your budget</span><strong><?php echo formatMoney($budget); ?></strong></div>
        <div class="cost-total"><span>Final Package Total</span><strong><?php echo formatMoney($total); ?></strong></div>
        <div class="budget-status <?php echo $withinBudget?'within':'over'; ?>"><?php echo $withinBudget?formatMoney($remaining).' remaining':'Over budget by '.formatMoney(abs($remaining)); ?></div>
      </aside>
    </div>

    <div class="p-4 p-md-5 pt-3">
      <div class="smart-trip-details-section">
        <div class="smart-trip-details-heading">
          <div><span>TRIP DETAILS</span><h2>Your generated package</h2></div>
        </div>
        <div class="smart-trip-details-grid">
          <div class="smart-trip-detail"><span>TRAVEL DATES</span><strong><?php echo e(date('d M Y',strtotime($trip['start_date']))); ?> – <?php echo e(date('d M Y',strtotime($trip['end_date']))); ?></strong></div>
          <div class="smart-trip-detail"><span>TRAVELERS</span><strong><?php echo $travelers; ?> Traveler<?php echo $travelers===1?'':'s'; ?></strong></div>
          <div class="smart-trip-detail"><span>TRANSPORT</span><strong><?php echo e($transport['provider']??'Included Transport'); ?></strong><small><?php echo e($transport['type']??'Travel'); ?></small></div>
          <div class="smart-trip-detail"><span>HOTEL</span><strong><?php echo e($hotel['name']??'Included Hotel'); ?></strong><small><?php echo $rooms; ?> room<?php echo $rooms===1?'':'s'; ?> · <?php echo e($hotel['room_type']??'Comfort Room'); ?></small></div>
          <div class="smart-trip-detail"><span>MEAL PLAN</span><strong><?php echo e($meal); ?></strong><small>Included throughout the trip</small></div>
          <div class="smart-trip-detail smart-trip-activities"><span>ACTIVITIES</span><strong><?php echo count($plan); ?> Included</strong><small class="smart-activity-list"><?php foreach($plan as $activity): ?><span><?php echo e($activity['name']); ?></span><?php endforeach; ?></small></div>
        </div>
      </div>

      <div class="planner-actions mt-4">
        <a href="smart-trip-planner.php" class="btn btn-outline-secondary">← Change Trip Details</a>
        <?php if ($withinBudget): ?>
          <a href="checkout.php?trip_id=<?php echo $tripId; ?>" class="btn btn-primary">Continue to Booking →</a>
        <?php else: ?>
          <span class="text-danger small align-self-center">This plan cannot be booked because it is over your budget.</span>
        <?php endif; ?>
      </div>
    </div>
  </section>
</div>
<script>
document.addEventListener('DOMContentLoaded',function(){
  const images=[...document.querySelectorAll('.smart-gallery-main-image')];
  const thumbs=[...document.querySelectorAll('.smart-gallery-thumb')];
  const label=document.getElementById('galleryLabel');
  thumbs.forEach((thumb,index)=>thumb.addEventListener('click',()=>{
    images.forEach((img,i)=>img.classList.toggle('active',i===index));
    thumbs.forEach((btn,i)=>btn.classList.toggle('active',i===index));
    if(label) label.textContent=thumb.querySelector('span').textContent;
  }));
});
</script>
<?php include 'includes/footer.php'; ?>
