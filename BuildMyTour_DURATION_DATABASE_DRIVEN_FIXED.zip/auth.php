<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    $sessionUserId = (int) currentUserId();
    $sessionUser = $pdo->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
    $sessionUser->execute([$sessionUserId]);

    if ($sessionUser->fetchColumn()) {
        header("Location: home.php");
        exit;
    }

    unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['selection']);
    session_regenerate_id(true);
}

$mode = $_GET['mode'] ?? 'login';
$mode = $mode === 'register' ? 'register' : 'login';

$loginErrors = [];
$registerErrors = [];
$success = flash('success');
$rememberedEmail = $_COOKIE['bmt_email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'login';

    if ($action === 'login') {
        $mode = 'login';
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email === '' || $password === '') {
            $loginErrors[] = "Please enter both email and password.";
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];

                if (!empty($_POST['remember'])) {
                    setcookie('bmt_email', $email, time() + (86400 * 30), "/");
                }

                header("Location: home.php");
                exit;
            }

            $loginErrors[] = "Invalid email or password.";
        }
    }

    if ($action === 'register') {
        $mode = 'register';
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        if ($name === '' || $email === '' || $phone === '' || $password === '') {
            $registerErrors[] = "Please fill all required fields.";
        }
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $registerErrors[] = "Please enter a valid email address.";
        }
        if ($password !== '' && strlen($password) < 6) {
            $registerErrors[] = "Password must be at least 6 characters long.";
        }
        if ($password !== $confirm) {
            $registerErrors[] = "Passwords do not match.";
        }

        if (empty($registerErrors)) {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);

            if ($stmt->fetch()) {
                $registerErrors[] = "An account with this email already exists.";
            }
        }

        if (empty($registerErrors)) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)"
            );
            $stmt->execute([$name, $email, $phone, $hash]);

            flash('success', 'Account created successfully! Please login to continue.');
            header("Location: auth.php?mode=login");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account - BuildMyTour</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
            <div class="card shadow-sm border-0 auth-card">
                <div class="card-body p-4 p-md-5">

                    <div class="text-center mb-4">
                        <a href="index.php" class="d-inline-block auth-logo-link">
                            <img src="assets/images/logo/buildmytour-logo.png" alt="BuildMyTour" class="auth-logo-img">
                        </a>
                        <p class="text-muted mb-0 mt-2">Plan smarter. Travel better.</p>
                    </div>

                    <ul class="nav nav-pills nav-fill auth-tabs mb-4" id="authTabs">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $mode === 'login' ? 'active' : ''; ?>"
                               href="auth.php?mode=login">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo $mode === 'register' ? 'active' : ''; ?>"
                               href="auth.php?mode=register">Create Account</a>
                        </li>
                    </ul>

                    <?php if ($success && $mode === 'login'): ?>
                        <div class="alert alert-success"><?php echo e($success); ?></div>
                    <?php endif; ?>

                    <?php if ($mode === 'login'): ?>
                        <div class="mb-4">
                            <h2 class="h4 mb-1">Welcome back</h2>
                            <p class="text-muted mb-0">Login to continue planning your trip.</p>
                        </div>

                        <?php foreach ($loginErrors as $error): ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endforeach; ?>

                        <form method="POST" action="auth.php?mode=login" novalidate>
                            <input type="hidden" name="action" value="login">

                            <div class="mb-3">
                                <label for="loginEmail" class="form-label">Email</label>
                                <input type="email" id="loginEmail" name="email" class="form-control"
                                       value="<?php echo e($_POST['email'] ?? $rememberedEmail); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="loginPassword" class="form-label">Password</label>
                                <input type="password" id="loginPassword" name="password" class="form-control" required>
                            </div>

                            <div class="form-check mb-4">
                                <input type="checkbox" name="remember" id="remember" class="form-check-input">
                                <label for="remember" class="form-check-label">Remember me</label>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">Login</button>
                        </form>

                        <div class="text-center mt-4">
                            <a href="auth.php?mode=register" class="auth-switch-link">Don't have an account? Create one</a>
                        </div>

                    <?php else: ?>
                        <div class="mb-4">
                            <h2 class="h4 mb-1">Create your account</h2>
                            <p class="text-muted mb-0">Create an account to start planning your trip.</p>
                        </div>

                        <?php foreach ($registerErrors as $error): ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endforeach; ?>

                        <form method="POST" action="auth.php?mode=register" novalidate>
                            <input type="hidden" name="action" value="register">

                            <div class="mb-3">
                                <label for="registerName" class="form-label">Full Name</label>
                                <input type="text" id="registerName" name="name" class="form-control"
                                       value="<?php echo e($_POST['name'] ?? ''); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="registerEmail" class="form-label">Email</label>
                                <input type="email" id="registerEmail" name="email" class="form-control"
                                       value="<?php echo e($_POST['email'] ?? ''); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="registerPhone" class="form-label">Phone</label>
                                <input type="text" id="registerPhone" name="phone" class="form-control"
                                       value="<?php echo e($_POST['phone'] ?? ''); ?>" required>
                            </div>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="registerPassword" class="form-label">Password</label>
                                    <input type="password" id="registerPassword" name="password" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="registerConfirm" class="form-label">Confirm Password</label>
                                    <input type="password" id="registerConfirm" name="confirm_password" class="form-control" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 mt-4">Create Account</button>
                        </form>

                        <div class="text-center mt-4">
                            <a href="auth.php?mode=login" class="auth-switch-link">Already have an account? Login</a>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
