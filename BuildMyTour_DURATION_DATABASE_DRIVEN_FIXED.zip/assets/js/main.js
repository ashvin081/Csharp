// BuildMyTour - small site interactions

document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.getElementById('navToggle');
    var nav = document.getElementById('mainNav');
    if (toggle && nav) {
        toggle.addEventListener('click', function () {
            nav.classList.toggle('open');
        });
    }

    document.querySelectorAll('.payment-method').forEach(function (method) {
        method.addEventListener('click', function () {
            document.querySelectorAll('.payment-method').forEach(function (item) {
                item.classList.remove('active');
            });
            method.classList.add('active');
            var input = method.querySelector('input');
            if (input) input.checked = true;
        });
    });
});
