# BuildMyTour — Smart Travel Planning and Booking System

## Latest project flow

`Login → Smart Trip Planner → Smart Tour Plan → Checkout & Payment → Booking Confirmation → My Bookings → Review`

## Smart Trip Planner inputs
- Trip Type
- Start Date
- Duration: 3, 4 or 7 days
- Travelers: 1–10
- Budget: ₹30,000 / ₹50,000 / ₹75,000 / ₹1,00,000 / ₹1,50,000 limits

The system matches an active package by trip type and duration and generates transport, hotel rooms, meal plan, activities and total price according to the number of travelers. If the cheapest matching package is above the selected total budget, the plan is still shown so the user can understand the actual cost, but booking is blocked until the budget is sufficient.

## Generated plan storage
The complete generated plan is stored in `trips.generated_plan_json` as JSON. This is generated plan data; there is no separate customization page.

## Database
Exactly 7 tables:
1. admins
2. users
3. trip_categories
4. tour_packages
5. trips
6. bookings
7. reviews

Import `database/buildmytour.sql` as the single database setup file. It creates the complete latest schema, including Smart Trip Planner.

## Images
- `assets/images/hero1.jpg` — Home hero
- `assets/images/packages/` — Tour Package images
- `assets/images/logo/` — Brand logo

Forms, checkout & payment, and admin management screens are intentionally kept image-light.

## Requirements
- XAMPP
- Apache
- MySQL / MariaDB
- PHP 8+
- Bootstrap 5.3 CDN

## XAMPP setup
1. Copy `BuildMyTour` to `htdocs`.
2. Start Apache and MySQL.
3. Open phpMyAdmin.
4. Import `database/buildmytour.sql` for a fresh setup.
5. Open `http://localhost/BuildMyTour/`.

Demo admin: `admin@buildmytour.com` / `admin123`


### Image setup
Tour package images are kept together in `assets/images/packages/<package-folder>/`. Each package has exactly four files: `destination.jpg`, `transport.jpg`, `hotel.jpg` and `meal-plan.jpg`. These supporting images are loaded from the package folder. There is no separate destinations table or admin destination page.

## Admin Tour Packages

From **Admin → Tour Packages**, use **+ Add Tour Package** to create a package. Enter the package details and upload four images: Destination, Transport, Hotel and Meal Plan. The images are saved inside that package's folder under `assets/images/packages/`. Edit keeps existing images unless a new image is selected. Delete removes the package and its image folder when the package is not linked to an existing trip.

The database stores the five image paths in the `tour_packages` record, so the package, planner gallery and admin list use the same image data.
