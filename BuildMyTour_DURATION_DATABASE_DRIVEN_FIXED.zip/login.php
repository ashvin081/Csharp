<?php
header('Location: auth.php?mode=login');
exit;
