<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';

requireLogin();
$pageTitle = 'Checkout & Payment';

$tripId = (int) ($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0);
$userId = (int) currentUserId();

$stmt = $pdo->prepare('SELECT * FROM trips WHERE id = ? AND user_id = ?');
$stmt->execute([$tripId, $userId]);
$trip = $stmt->fetch();

if (!$trip) {
    header('Location: smart-trip-planner.php');
    exit;
}

// Do not create another booking when an already booked trip is opened again.
if (($trip['booking_status'] ?? 'not_booked') !== 'not_booked') {
    header('Location: booking-confirmation.php?trip_id=' . $tripId);
    exit;
}

$package = getTourPackage($pdo, (int) $trip['package_id']);
if (!$package) {
    header('Location: smart-trip-planner.php');
    exit;
}

$storedPlan = !empty($trip['generated_plan_json'])
    ? json_decode($trip['generated_plan_json'], true)
    : [];
$storedPlan = is_array($storedPlan) ? $storedPlan : [];
$selection = $_SESSION['selection'][$tripId] ?? $storedPlan;

$travelers = max(1, (int) $trip['travelers']);
$pricePerPerson = (float) $package['price'];
$totalAmount = round($pricePerPerson * $travelers, 2);
$withinBudget = $totalAmount <= (float)$trip['budget'];
if (!$withinBudget) {
    flash('error', 'This trip costs ' . formatMoney($totalAmount) . ' for ' . $travelers . ' traveler' . ($travelers === 1 ? '' : 's') . ', which is above your selected budget of ' . formatMoney((float)$trip['budget']) . '.');
    header('Location: generated-tour-plan.php?trip_id=' . $tripId);
    exit;
}

$errors = [];
$selectedMethod = $_POST['payment_method'] ?? 'UPI';
$agreed = isset($_POST['agree']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentMethod = $_POST['payment_method'] ?? '';

    if (!in_array($paymentMethod, ['UPI', 'Card'], true)) {
        $errors[] = 'Please choose a payment method.';
    }

    if (!$agreed) {
        $errors[] = 'Please agree to the booking terms.';
    }

    if (!$errors) {
        $bookingReference = generateBookingReference();
        $transactionId = generateTransactionId();
        try {
            $pdo->beginTransaction();

            $updateTrip = $pdo->prepare(
                "UPDATE trips SET
                    booking_reference = ?,
                    total_amount = ?,
                    payment_method = ?,
                    transaction_id = ?,
                    payment_status = 'success',
                    booking_status = 'pending',
                    status = 'booked'
                 WHERE id = ? AND user_id = ? AND booking_status = 'not_booked'"
            );

            $updateTrip->execute([
                $bookingReference,
                $totalAmount,
                $paymentMethod,
                $transactionId,
                $tripId,
                $userId
            ]);

            if ($updateTrip->rowCount() !== 1) {
                throw new RuntimeException('Trip is already booked.');
            }

            $insertBooking = $pdo->prepare(
                'INSERT INTO bookings
                (trip_id, user_id, booking_reference, amount, booking_status, payment_method, payment_status, payment_reference)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $insertBooking->execute([
                $tripId,
                $userId,
                $bookingReference,
                $totalAmount,
                'pending',
                $paymentMethod,
                'success',
                $transactionId
            ]);

            $pdo->commit();
            unset($_SESSION['selection'][$tripId]);

            header('Location: booking-confirmation.php?trip_id=' . $tripId);
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('BuildMyTour checkout error: ' . $e->getMessage());
            $errors[] = 'Booking could not be completed. Please try again.';
        }
    }
}

include 'includes/header.php';
?>

<div class="container py-4 py-md-5">
    <div class="page-header checkout-simple-header">
        <h1>Checkout &amp; Payment</h1>
        <p>Review your trip and confirm your booking.</p>
    </div>

    <?php foreach ($errors as $error): ?>
        <div class="alert alert-error"><?php echo e($error); ?></div>
    <?php endforeach; ?>

    <div class="checkout-simple-card">
        <div class="checkout-simple-grid">
            <div class="checkout-main">
                <div class="checkout-label">YOUR TRIP</div>
                <h2><?php echo e($package['name']); ?></h2>
                <p class="checkout-trip-meta">
                    <?php echo e(date('d M Y', strtotime($trip['start_date']))); ?> –
                    <?php echo e(date('d M Y', strtotime($trip['end_date']))); ?>
                    &nbsp;•&nbsp; <?php echo (int) $trip['days']; ?> Days
                    &nbsp;•&nbsp; <?php echo $travelers; ?> Travelers
                </p>




                <form method="POST" action="checkout.php?trip_id=<?php echo $tripId; ?>">
                    <input type="hidden" name="trip_id" value="<?php echo $tripId; ?>">

                    <div class="checkout-section">
                        <h3>Payment Method</h3>
                        <p class="checkout-note">Demo payment only — no real money will be charged.</p>

                        <div class="payment-methods payment-methods-simple">
                            <?php foreach (['UPI', 'Card'] as $method): ?>
                                <label class="payment-method<?php echo $selectedMethod === $method ? ' active' : ''; ?>">
                                    <input type="radio" name="payment_method" value="<?php echo e($method); ?>" <?php echo $selectedMethod === $method ? 'checked' : ''; ?> required>
                                    <span><?php echo e($method); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <label class="checkbox-row checkout-agree">
                        <input type="checkbox" name="agree" <?php echo $agreed ? 'checked' : ''; ?> required>
                        <span>I agree to the booking terms.</span>
                    </label>

                    <button type="submit" class="btn btn-primary checkout-confirm-btn">
                        Confirm &amp; Pay <?php echo formatMoney($totalAmount); ?>
                    </button>
                </form>
            </div>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.payment-method input').forEach(function (input) {
        input.addEventListener('change', function () {
            document.querySelectorAll('.payment-method').forEach(function (item) {
                item.classList.remove('active');
            });
            input.closest('.payment-method').classList.add('active');
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
