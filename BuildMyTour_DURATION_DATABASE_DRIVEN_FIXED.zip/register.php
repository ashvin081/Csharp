<?php
header('Location: auth.php?mode=register');
exit;
