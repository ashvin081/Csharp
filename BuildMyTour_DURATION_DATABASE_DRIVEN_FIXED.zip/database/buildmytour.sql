CREATE DATABASE IF NOT EXISTS buildmytour CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE buildmytour;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS trips;
DROP TABLE IF EXISTS tour_packages;
DROP TABLE IF EXISTS trip_categories;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS admins;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE trip_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE tour_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(180) NOT NULL UNIQUE,
    description TEXT,
    duration VARCHAR(60) DEFAULT NULL,
    days INT NOT NULL DEFAULT 1,
    route VARCHAR(500) DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    image_destination VARCHAR(255) DEFAULT NULL,
    image_transport VARCHAR(255) DEFAULT NULL,
    image_hotel VARCHAR(255) DEFAULT NULL,
    image_meal_plan VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES trip_categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    destination VARCHAR(180) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT NOT NULL DEFAULT 1,
    travelers INT NOT NULL DEFAULT 1,
    budget DECIMAL(10,2) NOT NULL DEFAULT 0,
    generated_plan_json LONGTEXT DEFAULT NULL,
    booking_reference VARCHAR(50) DEFAULT NULL UNIQUE,
    total_amount DECIMAL(10,2) DEFAULT NULL,
    payment_method ENUM('UPI','Card') DEFAULT NULL,
    transaction_id VARCHAR(100) DEFAULT NULL,
    payment_status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
    booking_status ENUM('not_booked','pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'not_booked',
    status ENUM('planned','booked','completed','cancelled') NOT NULL DEFAULT 'planned',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES tour_packages(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trip_id INT NOT NULL,
    user_id INT NOT NULL,
    booking_reference VARCHAR(50) NOT NULL UNIQUE,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,
    booking_status ENUM('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
    payment_method ENUM('UPI','Card') DEFAULT NULL,
    payment_status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
    payment_reference VARCHAR(100) DEFAULT NULL,
    UNIQUE KEY uq_booking_trip (trip_id),
    FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trip_id INT NOT NULL,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    rating TINYINT NOT NULL,
    comment TEXT,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES tour_packages(id) ON DELETE CASCADE,
    UNIQUE KEY uq_trip_review (trip_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Demo admin: admin@buildmytour.com / admin123
INSERT INTO admins (name,email,password,status) VALUES
('Admin','admin@buildmytour.com','$2y$12$03m3wAMfw2dorevPiyy4gOFXGOE0r218QE6GQVe2HrfH7UkEQDxG6','active');

INSERT INTO trip_categories (name,description,status) VALUES
('Explore & Adventure','Explore nature, wildlife and thrilling adventures','active'),
('Culture & Heritage','Discover India''s culture, history and iconic destinations','active'),
('Temple Tours','Discover sacred temples, ancient traditions and meaningful journeys','active');

-- Each tour package stores four image paths: destination, transport, hotel and meal plan.
-- Budget in trips is the user's total trip budget for all selected travelers. Package price is per person.

INSERT INTO tour_packages (category_id,name,description,duration,days,route,price,image_destination,image_transport,image_hotel,image_meal_plan,status) VALUES
(1,'Leh–Ladakh Adventure Expedition','Leh, Nubra Valley and Pangong Lake adventure journey.','7 Days / 6 Nights',7,'Leh → Nubra Valley → Pangong Lake',52000,'assets/images/packages/leh-ladakh/destination.jpg','assets/images/packages/leh-ladakh/transport.jpg','assets/images/packages/leh-ladakh/hotel.jpg','assets/images/packages/leh-ladakh/meal-plan.jpg','active'),
(2,'Rajasthan Royal Heritage Journey','Jaipur, Udaipur and Jaisalmer royal heritage journey.','7 Days / 6 Nights',7,'Jaipur → Udaipur → Jaisalmer',38000,'assets/images/packages/rajasthan-royal/destination.jpg','assets/images/packages/rajasthan-royal/transport.jpg','assets/images/packages/rajasthan-royal/hotel.jpg','assets/images/packages/rajasthan-royal/meal-plan.jpg','active'),
(3,'Ujjain–Omkareshwar Temple Tour','Sacred temple journey across Ujjain and Omkareshwar.','4 Days / 3 Nights',4,'Ujjain → Omkareshwar',12000,'assets/images/packages/ujjain-omkareshwar/destination.jpg','assets/images/packages/ujjain-omkareshwar/transport.jpg','assets/images/packages/ujjain-omkareshwar/hotel.jpg','assets/images/packages/ujjain-omkareshwar/meal-plan.jpg','active'),
(1,'Gir Wildlife Safari Adventure','Wildlife and safari experience in Gir.','3 Days / 2 Nights',3,'Gir',15000,'assets/images/packages/gir-wildlife/destination.jpg','assets/images/packages/gir-wildlife/transport.jpg','assets/images/packages/gir-wildlife/hotel.jpg','assets/images/packages/gir-wildlife/meal-plan.jpg','active'),
(2,'Kutch White Desert & Cultural Escape','White Rann, Dhordo and Kutch culture.','4 Days / 3 Nights',4,'Bhuj → Dhordo → White Rann',18000,'assets/images/packages/kutch-white-desert/destination.jpg','assets/images/packages/kutch-white-desert/transport.jpg','assets/images/packages/kutch-white-desert/hotel.jpg','assets/images/packages/kutch-white-desert/meal-plan.jpg','active'),
(3,'Rishikesh Adventure & Spiritual Escape','River adventure, temples and peaceful Ganga experiences.','4 Days / 3 Nights',4,'Rishikesh',14000,'assets/images/packages/rishikesh-adventure/destination.jpg','assets/images/packages/rishikesh-adventure/transport.jpg','assets/images/packages/rishikesh-adventure/hotel.jpg','assets/images/packages/rishikesh-adventure/meal-plan.jpg','active');

