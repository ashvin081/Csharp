<?php
require_once 'includes/auth.php';

if (isLoggedIn()) {
    header("Location: home.php");
} else {
    header("Location: login.php");
}
exit;
