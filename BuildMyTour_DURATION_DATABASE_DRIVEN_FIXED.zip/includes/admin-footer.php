        </main>
        <footer class="admin-footer">
            <span>&copy; <?php echo date('Y'); ?> BuildMyTour Admin Panel</span>
            <span>College Mini Project</span>
        </footer>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
