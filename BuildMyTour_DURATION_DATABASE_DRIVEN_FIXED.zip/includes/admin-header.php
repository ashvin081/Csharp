<?php
$currentAdminPage = basename($_SERVER['PHP_SELF']);
$adminName = $_SESSION['admin_name'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? e($pageTitle) . ' - Admin - BuildMyTour' : 'Admin - BuildMyTour'; ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-body">
<div class="admin-layout">
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="admin-brand">
            <a href="dashboard.php" class="admin-logo admin-logo-link" aria-label="BuildMyTour Admin Dashboard">
    <img src="../assets/images/logo/buildmytour-logo.png" alt="BuildMyTour" class="admin-logo-img">
</a>
            <div class="admin-panel-label">ADMIN PANEL</div>
        </div>

        <nav class="admin-sidebar-nav">
            <a href="dashboard.php" class="admin-nav-link <?php echo $currentAdminPage === 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a>

            <div class="admin-nav-section">MANAGEMENT</div>
            <a href="users.php" class="admin-nav-link <?php echo $currentAdminPage === 'users.php' ? 'active' : ''; ?>">Users</a>

            <div class="admin-nav-section">SMART PLANNER CONTENT</div>
            <a href="trip-types.php" class="admin-nav-link <?php echo $currentAdminPage === 'trip-types.php' ? 'active' : ''; ?>">Trip Types</a>
            <a href="tour-packages.php" class="admin-nav-link <?php echo $currentAdminPage === 'tour-packages.php' ? 'active' : ''; ?>">Tour Packages</a>

            <div class="admin-nav-section">BOOKING OPERATIONS</div>
            <a href="bookings.php" class="admin-nav-link <?php echo $currentAdminPage === 'bookings.php' ? 'active' : ''; ?>">Bookings</a>
            <a href="reviews.php" class="admin-nav-link <?php echo $currentAdminPage === 'reviews.php' ? 'active' : ''; ?>">Reviews</a>
        </nav>

        <div class="admin-sidebar-bottom">
            <div class="admin-profile"><span class="admin-avatar">A</span><div><strong><?php echo e($adminName); ?></strong><small>Administrator</small></div></div>
            <a href="logout.php" class="admin-logout-link">Logout</a>
        </div>
    </aside>

    <div class="admin-main-shell">
        <header class="admin-topbar">
            <button class="admin-menu-toggle" type="button" aria-label="Open menu" onclick="document.body.classList.toggle('admin-sidebar-open')">☰</button>
            <div class="admin-topbar-title"><?php echo isset($pageTitle) ? e($pageTitle) : 'Admin Panel'; ?></div>
            <div class="admin-topbar-user"><span class="admin-topbar-avatar">A</span><span><?php echo e($adminName); ?></span></div>
        </header>
        <main class="admin-content">
