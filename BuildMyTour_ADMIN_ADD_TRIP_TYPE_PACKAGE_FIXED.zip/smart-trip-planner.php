<?php
require_once 'includes/auth.php'; require_once 'includes/functions.php'; require_once __DIR__.'/config/database.php'; requireLogin();
$pageTitle='Smart Trip Planner';
$categories=getTripCategories($pdo);
$error=flash('error');
include 'includes/header.php';
?>
<section class="smart-planner-hero"><div class="container"><span class="smart-planner-eyebrow">SMART TRIP PLANNER</span><h1>Tell us about your trip.</h1><p>Choose your travel type, duration, travelers and budget. BuildMyTour will create a complete ready-to-book tour plan.</p></div></section>
<div class="container smart-planner-page py-4 py-md-5">
  <?php if($error): ?><div class="alert alert-danger shadow-sm" role="alert"><?php echo e($error); ?></div><?php endif; ?>
  <div class="planner-progress planner-progress-compact"><div class="progress-step active"><span>1</span><b>Trip Details</b></div><i>→</i><div class="progress-step"><span>2</span><b>Smart Tour Plan</b></div></div>
  <form method="POST" action="generate-trip.php" class="smart-planner-card card border-0 shadow-sm">
    <div class="card-body p-4 p-md-5">
      <div class="smart-section-heading"><div class="smart-step-icon">1</div><div><span>TRIP DETAILS</span><h2>Plan your journey</h2><p>Use the available choices so the planner can match a suitable complete package.</p></div></div>
      <div class="row g-4">
        <div class="col-md-6"><label class="form-label">Trip Type</label><select name="category" class="form-select" required><option value="">Select trip type</option><?php foreach($categories as $name=>$meta): ?><option value="<?php echo e($name); ?>"><?php echo e($name); ?></option><?php endforeach; ?></select></div>
        <div class="col-md-6"><label class="form-label">Start Date</label><input type="date" name="start_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" required></div>
        <div class="col-md-4"><label class="form-label">Trip Duration</label><select name="duration_days" id="durationDays" class="form-select" required disabled><option value="">Select trip type first</option></select><div class="form-text">Available durations are matched to the selected trip type.</div></div>
        <div class="col-md-4"><label class="form-label">Travelers</label><select name="travelers" class="form-select" required><?php for($i=1;$i<=10;$i++): ?><option value="<?php echo $i; ?>" <?php echo $i===2?'selected':''; ?>><?php echo $i; ?> <?php echo $i===1?'Traveler':'Travelers'; ?></option><?php endfor; ?></select></div>
        <div class="col-md-4"><label class="form-label">Total Budget</label><select name="budget" class="form-select" required><option value="">Select budget</option><option value="30000">Up to ₹30,000</option><option value="50000">Up to ₹50,000</option><option value="75000">Up to ₹75,000</option><option value="100000">Up to ₹1,00,000</option><option value="150000">Up to ₹1,50,000</option></select></div>
      </div>
      <div class="planner-smart-note mt-4"><strong>How it works</strong><span>Your selections determine the package, transport, hotel room requirement, meal plan, activities and total price.</span></div>
      <div class="planner-actions mt-4"><button type="submit" class="btn btn-primary">Find My Smart Tour Plan →</button></div>
    </div>
  </form>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const category = document.querySelector('select[name="category"]');
  const duration = document.getElementById('durationDays');
  const durationMap = {
    'Explore & Adventure': [3, 7],
    'Culture & Heritage': [4, 7],
    'Temple Tours': [4]
  };
  const labels = {3:'3 Days / 2 Nights',4:'4 Days / 3 Nights',7:'7 Days / 6 Nights'};
  function refreshDurations() {
    const values = durationMap[category.value] || [];
    duration.innerHTML = '<option value="">Select duration</option>';
    values.forEach(function(days){
      const option=document.createElement('option');
      option.value=days; option.textContent=labels[days]; duration.appendChild(option);
    });
    duration.disabled = values.length === 0;
    if (values.length === 1) duration.value = String(values[0]);
  }
  category.addEventListener('change', refreshDurations);
  refreshDurations();
});
</script>
<?php include 'includes/footer.php'; ?>
